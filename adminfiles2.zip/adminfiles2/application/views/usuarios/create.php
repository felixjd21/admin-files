<div class="container separador4 ">
    <h1>Registro de usuarios</h1>
    <br>
    <br>
    <div class="row">
        <div class="col-md-6 ">
            <?php  
            $email = array('type'=> 'email','name' => 'email','id' => 'email', 'value' => set_value('email'),'class' => 'form-control input-lg', 'required'=>'required'); 

            $login = array('type'=> 'text','name' => 'login','id' => 'login', 'value' => set_value('login'),'class' => 'form-control input-lg', 'required'=>'required');

            $pass = array('name' => 'pass','id' => 'pass','class' => 'form-control input-lg', 'required'=>'required');
            $nombre = array('type'=> 'text','name' => 'nombre','id' => 'nombre', 'value' => set_value('nombre'),'class' => 'form-control input-lg', 'required'=>'required');
            
            $telefono = array('type'=> 'text','name' => 'telefono','id' => 'telefono', 'value' => set_value('telefono'),'class' => 'form-control input-lg');
                       
            $enviar = array('name'=>'registrar','value'=>'Registrar','class'=>'btn btn-success');
            $reset = array('name'=>'reset','value'=>'Borrar datos','class'=>'btn btn-default');
            ?>
           <?php if(validation_errors()==TRUE){ ?>
               <div class="alert alert-danger" role="alert">
                    <?= validation_errors(); ?>                   
               </div>                 
            <?php }

            if($resultado!=""){ ?>
                <div class="alert alert-success" role="alert">
                    <?= $resultado ?>                   
               </div> 
            <?php }
            ?>

            <?= form_open(base_url()."usuario/create");?>
            <div class="form-group">
                <label for="<?= $email['id']?>">Correo electrónico</label>
                <?= form_input($email);?>
            </div>
            <div class="form-group">
                <label for="<?= $login['id']?>">Login</label>
                <?=form_input($login);?>
            </div>
            <div class="form-group">
                <label for="<?= $pass['id']?>">Constraseña</label>
                <?=form_password($pass);?>
            </div>
            <div class="form-group">
                <label for="<?= $nombre['id']?>">Nombre</label>
                <?=form_input($nombre);?>
            </div>
            
           
           
            <div class="form-group">
               
            </div>
           
            <?= form_submit($enviar)?>
            <?= form_reset($reset);?>
            <?= form_close()?>
        </div>
    </div>
</div>
<br>
<br>
