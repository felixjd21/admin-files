<div class="row">
	<div class="col-xs-12">
		<h3>Listado de usuarios </h3>		
	</div>
	<div class="col-md-3">
		<a href="usuario/create"><button class="btn btn-success">Nuevo usuario</button></a>
	</div>
	<div class="col-md-7">
		<?= form_open(base_url()."usuario/buscar");?>
		<?php $this->load->view('usuarios/form_buscar');?>
		<?= form_close()?>		
	</div>
	<div class="col-md-2">
		<a href="<?= base_url($this->config->item('adm'))?>/usuario/reset"><button class="btn btn-danger btn-block">Mostrar todo</button></a>
	</div>
</div>

<div class="row">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<div class="table-responsive">
			<table class="table table-striped table-bordered table-condensed table-hover">
				<thead>
					<th>Id</th>
					<th>Nombre</th>
					<th>Login</th>
					<th>Email</th>
					<th>Tipo</th>
					<th >Opciones</th>
				</thead>
               <?php 
               	if($usuario !=FALSE):
               	foreach ($usuario as $user):
              		if($user->idperfiles==1)
              			$tipo = "Administrador";
              		else
              			$tipo = "Suscriptor";
              		?>
				<tr>
					<td><?= $user->idusers ?></td>
					<td><?= $user->name ?></td>
					<td><?= $user->username ?></td>
					<td><?= $user->email ?></td>
					<td><?= $tipo ?></td>
					<td>
						<a href="<?= base_url().'usuario/edit/'.$user->idusers?>"><button class="btn btn-info">Editar</button></a>
						<a href="<?= base_url().'usuario/verarchivos/'.$user->idusers?>"><button class="btn btn-warning">Archivos</button></a>
                        <?php
                        if($user->idperfiles!=1):?>
                        	<a href="" data-target="#modal-delete-<?= $user->idusers?>" data-toggle="modal"><button class="btn btn-danger">Eliminar</button></a>
                        <?php                       
                        endif;?>
					</td>
				</tr>
				<?php 
				$dat = array('id_user'=>$user->idusers);
				$this->load->view('usuarios/modal', $dat); ?>				
				<?php endforeach; 
				endif;?>
			</table>
		</div>
		<?= $paginacion ?>
	</div>
</div>