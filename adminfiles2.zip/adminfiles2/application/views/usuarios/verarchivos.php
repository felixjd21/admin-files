<div class="row">
	<div class="col-xs-12">
		<h3>Listado de archivos del usuario: 
			<?php if($user !=FALSE):
				echo '<b>'.$user->name.'</b>';
			endif;				
			?> 
			
		</h3>


		
	</div>

	<div class="col-md-3">
		<a href="<?=base_url()?>archivo/create"><button class="btn btn-success">Nuevo archivo</button></a>
	</div>
	<div class="col-md-7">
		<?= form_open(base_url()."usuario/buscar_archivo_user");?>
		<?php $this->load->view('usuarios/form_buscar_archivo');?>
		<?= form_close()?>	
	</div>
	<div class="col-md-2">
		<a href="<?= base_url()?>usuario/reset_archivo"><button class="btn btn-danger btn-block">Mostrar todo</button></a></h3>
		
	</div>
</div>

<div class="row">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<div class="table-responsive">
			<table class="table table-striped table-bordered table-condensed table-hover">
				<thead>
					<th>Id</th>
					<th>Titulo del archivo</th>
					<th>Autor</th>
					<th width="20%">Opciones</th>
				</thead>
               <?php 
               if($archivo !=FALSE):
               foreach ($archivo as $arch):?>
				<tr>
					<td><?= $arch->idarchivo ?></td>
					<td><?= anchor(base_url().'uploads/'.$arch->nombre, $arch->titulo, 'title="'.$arch->titulo.'" target="_black"');?></td>
					<td><?= $arch->autor ?></td>
					<td>
						<a href="<?= base_url().'uploads/'.$arch->nombre ?>" class="btn btn-info" title="<?=$arch->titulo ?>" target="_black">Ver archivo</a> 
						<!-- <a href="<?= base_url().'archivo/edit/'.$arch->idarchivo?>"><button class="btn btn-info">Editar</button></a>-->
                         <a href="" data-target="#modal-delete-<?= $arch->idarchivo?>" data-toggle="modal"><button class="btn btn-danger">Eliminar</button></a>
					</td>
				</tr>
				<?php 
				$dat = array('id_arch'=>$arch->idarchivo);
				$this->load->view('ficheros/modal', $dat); ?>				
				<?php endforeach; 
				endif;?>
			</table>
		</div>
		<?= $paginacion ?>
	</div>
</div>