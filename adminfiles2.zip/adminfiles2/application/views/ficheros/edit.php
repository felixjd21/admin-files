<div class="container separador4 ">
    <h1>Registro de usuarios</h1>
    <br>
    <br>
    <div class="row">
        <div class="col-md-6 ">
            <?php  
            $email = array('type'=> 'email','name' => 'email','id' => 'email', 'value' => $usuario->email,'class' => 'form-control input-lg', 'disabled'=>'disabled'); 
            

            $login = array('type'=> 'text','name' => 'login','id' => 'login', 'value' => $usuario->username,'class' => 'form-control input-lg', 'disabled'=>'disabled');
            $pass = array('name' => 'pass','id' => 'pass','class' => 'form-control input-lg');
            $nombre = array('type'=> 'text','name' => 'nombre','id' => 'nombre', 'value' => $usuario->name,'class' => 'form-control input-lg', 'required'=>'required');            
            $telefono = array('type'=> 'text','name' => 'telefono','id' => 'telefono', 'value' => set_value('telefono'),'class' => 'form-control input-lg');                       
            $enviar = array('name'=>'actualizar','value'=>'Actualizar','class'=>'btn btn-success');
            $reset = array('name'=>'reset','value'=>'Borrar datos','class'=>'btn btn-default');
            ?>
           <?php if(validation_errors()==TRUE){ ?>
               <div class="alert alert-danger" role="alert">
                    <?= validation_errors(); ?>                   
               </div>                 
            <?php }

            if($resultado!=""){ ?>
                <div class="alert alert-success" role="alert">
                    <?= $resultado ?>                   
               </div> 
            <?php }
            ?>

            <?= form_open(base_url()."usuario/update");?>
            <div class="form-group">
               
                <input type="hidden" name="id" value="<?= $usuario->idusers;?>">
                <label for="<?= $email['id']?>">Correo electrónico</label>
                <?= form_input($email);?>
            </div>
            <div class="form-group">
                <label for="<?= $login['id']?>">Login</label>
                <?=form_input($login);?>
            </div>
            <div class="form-group">
                <label for="<?= $pass['id']?>">Constraseña</label>
                <?=form_password($pass);?>
            </div>
            <div class="form-group">
                <label for="<?= $nombre['id']?>">Nombre</label>
                <?=form_input($nombre);?>
            </div>            
            <div class="form-group">
                <label for="<?= $telefono['id']?>">Teléfono(s)</label>
                <?= form_input($telefono);?>
            </div>           
            <div class="form-group">               
            </div>           
            <?= form_submit($enviar)?>
            
            <?= form_close()?>
        </div>
    </div>
</div>
<br>
<br>
