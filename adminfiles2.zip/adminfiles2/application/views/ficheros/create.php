<div class="container separador4 ">
    <h1>Subir archivo</h1>
    <br>
    <br>
    <div class="row">
        <div class="col-md-6 ">
            <?php  
            $titulo = array('type'=> 'text','name' => 'titulo','id' => 'titulo', 'value' => set_value('titulo'),'class' => 'form-control input-lg', 'required'=>'required');                                
            $enviar = array('name'=>'enviar','value'=>'Subir archivo','class'=>'btn btn-success');
            $reset = array('name'=>'reset','value'=>'Borrar datos','class'=>'btn btn-default');
            ?>
           <?php if(validation_errors()==TRUE){ ?>
               <div class="alert alert-danger" role="alert">
                    <?= validation_errors(); ?>                   
               </div>                 
            <?php }

            if($resultado!=""){ ?>
                <div class="alert alert-success" role="alert">
                    <?= $resultado ?>                   
               </div> 
            <?php }
            echo $error;
            ?>

            <?= form_open_multipart(base_url()."archivo/create");?>            
            <div class="form-group">
                <label for="<?= $titulo['id']?>">Titulo</label>
                <?=form_input($titulo);?>
            </div> 
            <?php if($this->session->userdata("perfil_sess")==1): ?>          
                <div class="form-group">
                    <label for="">Usuario</label> 
                    <select class="form-control input-lg"  name="usuario" id="usuario" required="required">
                        <option value="">Seleccione...</option>
                        <?php foreach ($user as $row): ?>
                           <option value="<?= $row->idusers?>"><?= $row->name?></option>
                        <?php endforeach; ?>                    
                    </select>               
                </div>
            <?php else: ?>
                <input type="hidden" name="usuario" value="<?= $this->session->userdata("idusers_sess")?>">
            <?php endif; ?>
            <input type="hidden" name="autor" value="<?= $this->session->userdata("nombre_sess")?>">
           
            <div class="form-group">
                <label>Archivo</label>
                <input type="file" name="userfile" size="20" required />
            </div>
           
            <?= form_submit($enviar)?>
            
            <?= form_close()?>
        </div>
    </div>
</div>
<br>
<br>
