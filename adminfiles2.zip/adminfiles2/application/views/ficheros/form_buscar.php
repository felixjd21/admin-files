		<div class="form-group">
			<div class="input-group">
				<input type="text" class="form-control" name="buscar" placeholder="Buscar..." value="<?= $this->session->userdata("buscar_file"); ?>">
				<span class="input-group-btn">
					<button type="submit" class="btn btn-primary">Buscar</button>
				</span>
			</div>
		</div>