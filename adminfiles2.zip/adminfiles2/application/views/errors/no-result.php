<div class="col-md-12">
	<div class="alert alert-danger" role="alert">
		<div align="center"><p><strong>! No hay resultado!</strong></p></div>
	</div>
</div>