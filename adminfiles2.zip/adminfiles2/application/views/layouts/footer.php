                                        <!--Fin Contenido-->
                                        </div>
                                    </div><!-- /.row -->
                                </div><!-- /.box-body -->
                            </div><!-- /.box -->
                        </div><!-- /.col -->
                    </div><!-- /.row -->
                </section><!-- /.content -->
            </div><!-- /.content-wrapper -->
            <!--Fin-Contenido-->
            <footer class="main-footer">
                <div class="pull-right hidden-xs">
                    <b>Version</b> 2.3.0
                </div>
                <strong>Copyright &copy; 2018-2020 <a href="http://www.jd21ca.com.ve">Corporacion Jd 21</a>.</strong> All rights reserved.
            </footer>
            <!-- jQuery 2.1.4 -->
            <script src="<?= base_url()?>assets/js/jQuery-2.1.4.min.js"></script>
            <!-- Bootstrap 3.3.5 -->
            <script src="<?= base_url()?>assets/js/bootstrap.min.js"></script>
            <!-- AdminLTE App -->
            <script src="<?= base_url()?>assets/js/app.min.js"></script>
        </body>
    </html>