<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
	
	public function __construct(){
		parent::__construct();				
		$this->load->library('session');
			
		if($this->session->userdata("login_sess")){
			redirect(base_url());					
		}else{
			$this->load->database();			
			$this->load->model('user');	
		}	
	}
	public function index()
	{			
		$valida_error ="";
	
		if($this->input->post("ingresar")){
			$login = $this->input->post("login");
			$pass = $this->input->post("password");

			$row = $this->user->show($login,$pass);

			if($row!=FALSE){
				$valida_error =" Usuario logeado correcto";
				$this->session->set_userdata('login_sess',1);
				$this->session->set_userdata('username_sess',$row->username);
				$this->session->set_userdata('idusers_sess',$row->idusers);
				$this->session->set_userdata('nombre_sess',$row->name);
				$this->session->set_userdata('email_sess',$row->email);
				$this->session->set_userdata('perfil_sess',$row->idperfiles);				
				//redirect(base_url());	?>
				<script type="text/javascript">
				location.href ="<?php base_url()?>/adminfiles";
			</script><?php	 

			}else{
				$valida_error = "<p style='color:red;'>Usuario y/o contraseña son invalidos</p>";
			}
		}
		$dat = array('titulo'=>' - Asesoria Froman - Iniciar Sesión',
			'valida_error' => $valida_error,			
		);
		$this->load->view('login',$dat);
	
	}
	function logout(){
		$array_items = array('login_sess','nombre_sess','email_sess','perfil_sess','username_sess','idusers_sess');
		$this->session->unset_userdata($array_items);		
	}	
	
}
