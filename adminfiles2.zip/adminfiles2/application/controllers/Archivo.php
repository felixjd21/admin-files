<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Archivo extends CI_Controller {
	
	public function __construct(){
		parent::__construct();
		$this->load->library('session');
		if($this->session->userdata("login_sess")){
			$this->load->database();	
			$this->load->library('pagination');	
			$this->load->library('form_validation'); 
			$this->load->model('user');
			$this->load->model('fichero');
		}else{
			redirect(base_url().'login');
		}		
	}
	public function index($nropagina = FALSE)
	{	
		$inicio = 0;
		$mostrarpor = 6;
		$buscador = "";
		

		if ($this->session->userdata("buscar_file")) {
			$buscador = $this->session->userdata("buscar_file");
		}
		if ($nropagina) {
			$inicio = ($nropagina - 1) * $mostrarpor;
		}

		$valida_error ="";	

		$dat = array('titulo'=>' - ficheros',
			'valida_error' => $valida_error,			
		);

		$this->load->view('layouts/header');
		

		if($this->session->userdata("perfil_sess")==1){
			$fichero = $this->fichero->buscar($buscador);
		}else{
			$fichero = $this->fichero->buscar_id($buscador);
		}


		$config['base_url']         = base_url()."archivo/";
		$config['total_rows']       = count($fichero);
		$config['per_page']         = $mostrarpor; 
		$config['uri_segment']      = 2;
		$config['num_links']        = 3;
		$config['use_page_numbers'] = TRUE;
		$config['full_tag_open']    = '<ul class="pagination">';
		$config['full_tag_close']   = '</ul>';
		$config['first_link']       = false;
		$config['last_link']        = false;
		$config['first_tag_open']   = '<li>';
		$config['first_tag_close']  = '</li>';
		$config['prev_link']        = '&laquo';
		$config['prev_tag_open']    = '<li class="prev">';
		$config['prev_tag_close']   = '</li>';
		$config['next_link']        = '&raquo';
		$config['next_tag_open']    = '<li>';
		$config['next_tag_close']   = '</li>';
		$config['last_tag_open']    = '<li>';
		$config['last_tag_close']   = '</li>';
		$config['cur_tag_open']     = '<li class="active"><a href="#">';
		$config['cur_tag_close']    = '</a></li>';
		$config['num_tag_open']     = '<li>';
		$config['num_tag_close']    = '</li>';

		$this->pagination->initialize($config); 
			
		
		if($this->session->userdata("perfil_sess")==1){
			$dat = array(
				'archivo'    => $this->fichero->buscar($buscador,$inicio,$mostrarpor),
				'paginacion' => $this->pagination->create_links(),		
			);				
		}

		elseif($this->session->userdata("perfil_sess")==2){
			$dat = array(
				'archivo'    => $this->fichero->buscar_id($buscador,$inicio,$mostrarpor),
				'paginacion' => $this->pagination->create_links(),		
			);
		}
		$this->load->view('ficheros/index',$dat);			
			
		$this->load->view('layouts/footer');	
	}
	

	public function create(){

		$resultado = "";
		$error ="";
		
		if($this->input->post("enviar")){		
			
			$config['upload_path']   = './uploads/';
			//$config['file_name']   = md5(time());
			$config['encrypt_name']  = TRUE;
			$config['allowed_types'] = 'gif|jpg|png|zip|pdf|doc|docx|xls|xlsx|ppt|pptx|rar';
            //$config['max_size']             = 100;
            //$config['max_width']            = 1024;
            //$config['max_height']           = 768;
			$titulo  = $this->input->post("titulo");			
			$usuario = $this->input->post("usuario");
			$autor   = $this->input->post("autor");
            $this->load->library('upload', $config);				

            if ( ! $this->upload->do_upload('userfile'))
            {                
                $dat['uploadError'] = $this->upload->display_errors();
	            $error = $this->upload->display_errors();            
                
            }
            else
            { 
                $error ="";
                $ar = array('upload_data'=> $this->upload->data());
                $datos = array(
					'titulo' => $titulo,
					'nombre' => $ar['upload_data']['file_name'],
					'autor'=> $autor,
					'idusers' => $usuario ,
				);
				// Ingreso los datos en la tabla archivo.
				$this->fichero->create($datos);
				$data['uploadSuccess'] = $this->upload->data();
				
            }
            ?><script type="text/javascript">
				location.href ="<?php base_url()?>/adminfiles/archivo";
			</script><?php   
			
            
		}
		//LLamo al modelo user para cargar los usuarios activos
		$user = $this->user->active();

		$dat = array(
			'titulo'    =>' - Subir Archivo',
			'resultado' => $resultado, 
			'error'     => $error, 
			'user'      =>$user
		);			
		
		$this->load->view('layouts/header',$dat);
		$this->load->view('ficheros/create');
		$this->load->view('layouts/footer');

	}

	public function buscar(){
		$this->session->set_userdata("buscar_file",$this->input->post("buscar"));
		if($this->session->userdata("buscar_file")){
			//redirect(base_url()."archivo");
		}
		?>
		<script type="text/javascript">
			location.href ="<?= base_url()?>archivo";
		</script><?php		
	}
	public function reset(){		
		$this->session->unset_userdata('buscar_file');		
		if($this->session->userdata("buscar_file")==FALSE){
			//redirect(base_url().'archivo');	
		}
		?>
		<script type="text/javascript">
			location.href ="<?= base_url()?>archivo";
		</script><?php	
	}

	
	// Eliminar archivo
	function delete(){
		$id = $this->input->post("idelimina");
		$delete = $this->fichero->delete($id);		
		//redirect(base_url().'archivo');
		?>
		<script type="text/javascript">
			location.href ="<?php base_url()?>archivo";
		</script><?php
	}	
	
}