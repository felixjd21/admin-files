<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Index extends CI_Controller {	
	
	public function __construct(){		
		parent::__construct();	
		$this->load->library('session');

		if($this->session->userdata("login_sess")!=1){
			redirect(base_url().'login');	
		}
	}

	public function index()
	{
		$dat['activo']="class= 'active'";				
		$this->load->view('layouts/header',$dat);
		$this->load->view('index');
		$this->load->view('layouts/footer');	
	}
	function logout(){
		$array_items = array('login_sess','nombre_sess','email_sess','perfil_sess','username_sess','idusers_sess','buscar_file_user', 'buscar_user');
		$this->session->unset_userdata($array_items);
		
		if($this->session->userdata("login_sess")!=1){
			redirect(base_url().'login');	
		}

	}		
}