<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Usuario extends CI_Controller {

	
	public function __construct(){
		parent::__construct();

		$this->load->library('session');
		if($this->session->userdata("login_sess")){
			if($this->session->userdata("perfil_sess")==2){
				redirect(base_url());
			}else{
				$this->load->database();	
				$this->load->library('pagination');	
				$this->load->library('form_validation'); 
				$this->load->model(array('user','fichero'));
			}		
		}else{
			redirect(base_url().'login');
		}		
	}

	public function index($nropagina = FALSE)
	{	
		$inicio = 0;
		$mostrarpor = 5;
		$buscador = "";
		
		//$datos_plantilla["cuerpo"] = $this->load->view('cuerpo_articulo', $arrayArticulo, true);

		if ($this->session->userdata("buscar_user")) {
			$buscador = $this->session->userdata("buscar_user");
		}
		if ($nropagina) {
			$inicio = ($nropagina - 1) * $mostrarpor;
		}
		$valida_error ="";	

		$dat = array('titulo'=>' - Usuarios',
			'valida_error' => $valida_error,			
		);


		$this->load->view('layouts/header');
		//if($this->user->buscar($buscador)!=FALSE){			

			$config['base_url'] = base_url()."usuario/";
			$config['total_rows'] = count($this->user->buscar($buscador));
			$config['per_page'] = $mostrarpor; 
			$config['uri_segment'] = 2;
			$config['num_links'] = 3;
			$config['use_page_numbers'] = TRUE;			

			$config['full_tag_open'] = '<ul class="pagination">';
			$config['full_tag_close'] = '</ul>';
			$config['first_link'] = false;
			$config['last_link'] = false;
			$config['first_tag_open'] = '<li>';
			$config['first_tag_close'] = '</li>';
			$config['prev_link'] = '&laquo';
			$config['prev_tag_open'] = '<li class="prev">';
			$config['prev_tag_close'] = '</li>';
			$config['next_link'] = '&raquo';
			$config['next_tag_open'] = '<li>';
			$config['next_tag_close'] = '</li>';
			$config['last_tag_open'] = '<li>';
			$config['last_tag_close'] = '</li>';
			$config['cur_tag_open'] = '<li class="active"><a href="#">';
			$config['cur_tag_close'] = '</a></li>';
			$config['num_tag_open'] = '<li>';
			$config['num_tag_close'] = '</li>';

			$this->pagination->initialize($config); 
				
			$dat = array(
				'usuario' => $this->user->buscar($buscador,$inicio,$mostrarpor),
				'paginacion' => $this->pagination->create_links(),		
			);
			$this->load->view('usuarios/index',$dat);
		//}else{
			//$this->load->view('errors/no-result');
			//$this->load->view('usuarios/index',$dat);
		//}		
		$this->load->view('layouts/footer');	
	}

	public function create(){

		$resultado = "";
		if($this->input->post("registrar")){

			$nombre = $this->input->post("nombre");
			$login = $this->input->post("login");
			$email = $this->input->post("email");
			$pass = md5($this->input->post("pass"));

			$this->form_validation->set_rules('login', 'Login','required|min_length[6]|max_length[12]|is_unique[users.username]');
			$this->form_validation->set_rules('email', 'Email','required|is_unique[users.email]');
			$this->form_validation->set_rules('pass', 'Contraseña','required|min_length[5]|max_length[12]');

			if ($this->form_validation->run() == FALSE)
	        {
	            $resultado = "";
	        }
	        else
	        {
	        	$datos = array(
					'username' => $login,
					'name' => $nombre,
					'email' => $email,
					'password' => $pass,
					'idperfiles' => 2,
					'active' => 1,			
				);
				$this->user->create($datos);
	        	$resultado = "Registro exitoso";
	        	$_POST['email']="";
				$_POST['login']="";
				$_POST['nombre']="";
				$_POST['pass']="";				
	        }					
		}
		$dat = array('titulo'=>' - Registro de usuario',
			'resultado' => $resultado,				
		);				
		$this->load->view('layouts/header',$dat);
		$this->load->view('usuarios/create');
		$this->load->view('layouts/footer');
	}

	public function buscar(){	

		$this->session->set_userdata("buscar_user",$this->input->post("buscar"));
		if($this->session->userdata("buscar_user")){
			redirect(base_url()."usuario");
		}
		?>
		<script type="text/javascript">
			location.href ="<?php base_url()?>/adminfiles/usuario";
		</script><?php	
	}
	public function reset(){		
		$this->session->unset_userdata('buscar_user');		
		if($this->session->userdata("buscar_user")==FALSE){
			redirect(base_url().'usuario');	
		}
	}

	// Rellena formulario para editar
	function edit(){
		$resultado  ="";
		$id = $this->uri->segment(3);
		$row = $this->user->edit($id);				
		$dat = array('titulo'=>' - Editar usuario',
			'usuario'=>$row,'resultado'=>$resultado,					
		);		
		$this->load->view('layouts/header',$dat);
		if($row!=FALSE){
			$this->load->view('usuarios/edit',$dat);
		}else{
			$this->load->view('errors/no-result');
		}
		$this->load->view('layouts/footer');
	}

	// Actualizar
	function update(){
		$id = $this->input->post("id");
		$nombre = $this->input->post("nombre");		
		$pass = $this->input->post("pass");
		$data = array('name'=>$nombre, 'password' => $pass);
		$this->user->update($data,$id);
		redirect(base_url().'usuario');
	}
	// Eliminar Usuario
	function delete(){
		$id = $this->input->post("idelimina");
		$this->user->delete($id);
		redirect(base_url().'usuario');
	}

	function verarchivos(){
		$id = $this->uri->segment(3);
		$nropagina = $this->uri->segment(4);
		$inicio = 0;
		$mostrarpor = 6;
		$buscador = "";		

		if ($this->session->flashdata("buscar_file_user")) {
			$buscador = $this->session->flashdata("buscar_file_user");
		}
		if ($nropagina) {
			$inicio = ($nropagina - 1) * $mostrarpor;
		}

		$valida_error ="";	
		$dat = array(
			'titulo'=>' - Ver archivos de usuario',);
				
		$fichero = $this->fichero->verarchivos($id,$buscador);	
		
		$this->load->view('layouts/header',$dat);
		$config['base_url'] = base_url()."usuario/verarchivos/$id/";
		$config['total_rows'] = count($fichero);
		$config['per_page'] = $mostrarpor; 
		$config['uri_segment'] = 4;
		$config['num_links'] = 3;
		$config['use_page_numbers'] = TRUE;			

		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';
		$config['first_link'] = false;
		$config['last_link'] = false;
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		$config['prev_link'] = '&laquo';
		$config['prev_tag_open'] = '<li class="prev">';
		$config['prev_tag_close'] = '</li>';
		$config['next_link'] = '&raquo';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="active"><a href="#">';
		$config['cur_tag_close'] = '</a></li>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';

		$this->pagination->initialize($config);

		$row = $this->user->edit($id);
		$dat = array(
			'user' =>$row,
			'valida_error' => $valida_error,			
			'archivo' => $this->fichero->verarchivos($id,$buscador,$inicio,$mostrarpor),
			'paginacion' => $this->pagination->create_links(),		
		);		 

		
			$this->load->view('usuarios/verarchivos',$dat);
		
		$this->load->view('layouts/footer');

	}

	public function buscar_archivo_user(){
		$id = $this->input->post("id");
		//$this->session->set_userdata("buscar_file_user",$this->input->post("buscar"));
		$this->session->set_flashdata('buscar_file_user', $this->input->post("buscar"));
		//$this->session->set_userdata("id_user_ar",$id);	
		//redirect(base_url()."archivo");
		?>
		<script type="text/javascript">
			location.href ="<?php base_url()?>/adminfiles/usuario/verarchivos/<?= $id ?>";
		</script><?php		
	}
	public function reset_archivo(){		
				
		if($this->session->flashdata("buscar_file_user")==FALSE){
			redirect(base_url().'usuario');	
		}
	}
	
	
}