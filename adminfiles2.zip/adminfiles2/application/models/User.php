<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Model Class

 */
class User extends CI_Model{

	public function __construct(){
		parent::__construct();
	}	

	public function show($login, $pass){
		$clave = md5($pass);
		$this->db->where('username',$login);			
		$this->db->where('password',$clave);
		$this->db->or_where('email',$login);									
		$query = $this->db->get("users");
		if($query->num_rows()>0){
			return $query->row();
		}else{
			return false;
		}		
	}
	public function create($data){	
	
		$this->db->insert('users', $data);
	}


	public function buscar($buscar, $inicio = FALSE, $cantidadregistro = FALSE)
	{
		$this->db->where('active','1');	
		$this->db->like("name",$buscar);
		$this->db->or_like('username',$buscar);
		$this->db->or_like('email',$buscar);
		
		if ($inicio !== FALSE && $cantidadregistro !== FALSE) {
			$this->db->limit($cantidadregistro,$inicio);
		}
		$consulta = $this->db->get("users");
		if($consulta->num_rows()>0){
			return $consulta->result();
		}else{
			return false;
		}		
	}
	public function edit($id)
	{
		$this->db->where('idusers',$id);
		$this->db->where('active',1);	
		$consulta = $this->db->get("users");
		if($consulta->num_rows()>0){
			return $consulta->row();
		}else{
			return false;
		}		
	}

	public function update($data,$id){		
		
		$this->db->set('name',$data['name']);
		if($data['password']!=""){
			$pass = md5($data['password']);	
			$this->db->set('password',$pass);
		}	
		$this->db->where('idusers', $id);
		$this->db->update('users'); 
	}

	public function delete($id){

		/*$this->db->set('active',0);		
		$this->db->where('idusers', $id);
		$this->db->update('users'); */
		$this->db->where('idusers', $id);
		$this->db->delete('users');
	}

	public function active(){
		$this->db->where('active','1');
		$query = $this->db->get("users");
		if($query->num_rows()>0){
			return $query->result();
		}else{
			return false;
		}		
	}
}
