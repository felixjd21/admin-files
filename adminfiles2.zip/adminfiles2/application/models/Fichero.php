<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Model Class

 */
class Fichero extends CI_Model{

	public function __construct(){
		parent::__construct();
	}

	public function index(){
		$this->db->select('idarchivo, titulo, nombre, name');
		$this->db->from('archivo');
		$this->db->order_by('name');
		$this->db->join('users','archivo.idusers = users.idusers');

	}
	
	public function create($data){		
		$this->db->insert('archivo', $data);
	}

	public function buscar($buscar, $inicio = FALSE, $cantidadregistro = FALSE)
	{
		$this->db->select('idarchivo,titulo,nombre,name,autor');
		$this->db->like("titulo",$buscar);
		$this->db->or_like("name",$buscar);
		$this->db->from('archivo');
		$this->db->order_by('name');
		$this->db->join('users','archivo.idusers = users.idusers');						
		if ($inicio !== FALSE && $cantidadregistro !== FALSE) {
			$this->db->limit($cantidadregistro,$inicio);
		}	
		$consulta = $this->db->get();
		if($consulta->num_rows()>0){
			return $consulta->result();
		}else{
			return false;
		}		
	}
	public function buscar_id($buscar, $inicio = FALSE, $cantidadregistro = FALSE)
	{
		$this->db->select('idarchivo,titulo,nombre,name, autor');
		$this->db->where('users.idusers', $this->session->userdata("idusers_sess"));
		$this->db->like("titulo",$buscar);
		$this->db->from('archivo');
		$this->db->order_by('name');
		$this->db->join('users','archivo.idusers = users.idusers');						
		if ($inicio !== FALSE && $cantidadregistro !== FALSE) {
			$this->db->limit($cantidadregistro,$inicio);
		}	
		$consulta = $this->db->get();
		if($consulta->num_rows()>0){
			return $consulta->result();
		}else{
			return false;
		}		
	}


	public function edit($id)
	{
		$this->db->where('idarchivo',$id);
		$consulta = $this->db->get("archivo");
		if($consulta->num_rows()>0){
			return $consulta->row();
		}else{
			return false;
		}		
	}

	public function update($data,$id){		
		
		$this->db->set('titulo',$data['name']);		
		$this->db->where('idarchivo', $id);
		$this->db->update('archivo'); 
	}

	public function delete($id){
		$this->db->where('idarchivo', $id);
		$this->db->delete('archivo');
	}

	public function verarchivos($iduser,$buscar, $inicio = FALSE, $cantidadregistro = FALSE){

		$this->db->select('idarchivo,titulo,nombre,name, autor');
		$this->db->where('users.idusers', $iduser);
		$this->db->like("titulo",$buscar);
		$this->db->from('archivo');
		$this->db->order_by('name');
		$this->db->join('users','archivo.idusers = users.idusers');						
		if ($inicio !== FALSE && $cantidadregistro !== FALSE) {
			$this->db->limit($cantidadregistro,$inicio);
		}	
		$consulta = $this->db->get();
		if($consulta->num_rows()>0){
			return $consulta->result();
		}else{
			return false;
		}		
	}

	
}
